package main

import (
	"encoding/json"
	"fmt"
	"net/http"

	"github.com/strata-io/service-extension/orchestrator"
)

func BuildAccessTokenClaims(api orchestrator.Orchestrator, req *http.Request) (map[string]any, error) {
	logger := api.Logger()
	logger.Debug("msg", "building access token claims from Keycloak session")

	session, err := api.Session()
	if err != nil {
		logger.Error("msg", "unable to retrieve session", "error", err.Error())
		return nil, err
	}

	claims := make(map[string]any)
	claims["iss"] = "https://maverics13.stratademo.io/realms/xylem"
	claims["typ"] = "Bearer"


	// Copy user identity claims from Keycloak session
	keycloakClaims := map[string]string{
		"email":              "Keycloak-2-Xylem-Vue.email",
		"given_name":         "Keycloak-2-Xylem-Vue.given_name",
		"family_name":        "Keycloak-2-Xylem-Vue.family_name",
		"name":               "Keycloak-2-Xylem-Vue.name",
		"preferred_username": "Keycloak-2-Xylem-Vue.email", // Map to user_name
		"email_verified":     "Keycloak-2-Xylem-Vue.email_verified",
		"locale":             "Keycloak-2-Xylem-Vue.locale",
		"nonce":              "Keycloak-2-Xylem-Vue.nonce",
		"acr":                "Keycloak-2-Xylem-Vue.acr",
	}

	// Extract claims from Keycloak session
	for claimName, sessionKey := range keycloakClaims {
		if value, err := session.GetString(sessionKey); err == nil && value != "" {
			// Parse specific claim types
			switch claimName {
			case "email_verified":
				claims[claimName] = value == "true"
			default:
				claims[claimName] = value
			}
			logger.Debug("msg", "mapped claim from Keycloak session", "claim", claimName, "value", value)
		}
	}

	// Set default audience
	claims["aud"] = []string{
		"realm-management",
		"go-aigua-water-twin",
		"go-aigua-iot",
		"account",
		"go-aigua-dmd",
	}

	// Set default allowed origins
	claims["allowed-origins"] = []string{"*"}

	// Handle realm_access - try to get from Keycloak session first
	if realmAccessStr, err := session.GetString("Keycloak-2-Xylem-Vue.realm_access"); err == nil && realmAccessStr != "" {
		var realmAccess map[string]interface{}
		if err := json.Unmarshal([]byte(realmAccessStr), &realmAccess); err == nil {
			claims["realm_access"] = realmAccess
			logger.Debug("msg", "used realm_access from Keycloak session")
		}
	}

	// If no realm_access from Keycloak, set defaults
	if _, exists := claims["realm_access"]; !exists {
		claims["realm_access"] = map[string]interface{}{
			"roles": []string{
				"APP_DMD",
				"APP_SMART_SCADA",
				"APP_GIS_VIEWER",
				"offline_access",
				"uma_authorization",
			},
		}
		logger.Debug("msg", "used default realm_access")
	}

	// Handle resource_access - try to get from Keycloak session first
//	if resourceAccessStr, err := session.GetString("Keycloak-2-Xylem-Vue.resource_access"); err == nil && resourceAccessStr != "" {
//		var resourceAccess map[string]interface{}
//		if err := json.Unmarshal([]byte(resourceAccessStr), &resourceAccess); err == nil {
///			claims["resource_access"] = resourceAccess
//			logger.Debug("msg", "used resource_access from Keycloak session")
//		}
//	}

	// If no resource_access from Keycloak, set comprehensive defaults
	if _, exists := claims["resource_access"]; !exists {
		claims["resource_access"] = map[string]interface{}{
			"realm-management": map[string]interface{}{
				"roles": []string{
					"manage-realm",
					"manage-users",
					"query-realms",
					"manage-clients",
					"query-clients",
					"query-groups",
					"query-users",
				},
			},
			"go-aigua-water-twin": map[string]interface{}{
				"roles": []string{
					"APP_WATER_TWIN",
					"APP_WATER_TWIN_ADMIN",
				},
			},
			"go-aigua-portal": map[string]interface{}{
				"roles": []string{
					"ADMIN_PORTAL_USERS",
					"PORTAL_APPS_ADMIN",
					"ADMIN_PORTAL_GIS",
					"APP_PORTAL_ADMIN",
				},
			},
			"go-aigua-iot": map[string]interface{}{
				"roles": []string{
					"APP_IOT_CORE_ALARMS_ADMIN",
					"APP_IOT_CORE",
					"APP_IOT_CORE_MANAGEMENT",
					"APP_IOT_CORE_IO_ADMIN",
				},
			},
			"account": map[string]interface{}{
				"roles": []string{
					"manage-account",
					"manage-account-links",
					"view-profile",
				},
			},
			"go-aigua-dmd": map[string]interface{}{
				"roles": []string{
					"DMD_APPLICATION_MODULE",
					"DMD_WRITE_CHARACTERISTIC",
					"DMD_WRITE_TEMPLATE",
					"DMD_WRITE_HIERARCHY_ITEM",
					"DMD_WRITE_API",
					"DMD_WRITE_HIERARCHY",
					"DMD_ASSET_MODULE",
					"DMD_RETRIEVE_HIERARCHY_ITEM",
					"DMD_ADMIN",
					"DMD_DOCUMENTATION_MODULE",
					"DMD_WRITE_ASSET",
					"DMD_READ_EXTERNAL_APPLICATION",
					"DMD_WRITE_CLASS",
					"DMD_READ_ASSET",
					"DMD_READ_API",
					"APP_DMD",
					"DMD_HIERARCHY_MODULE",
					"DMD_READ_HIERARCHY",
					"DMD_READ_TEMPLATE",
					"DMD_WRITE_MEASUREMENT",
					"DMD_WRITE_EXTERNAL_APPLICATION",
					"DMD_UNIT_MODULE",
				},
			},
		}
		logger.Debug("msg", "used default comprehensive resource_access")
	}

	// Set default values for missing standard claims
	setDefaultClaims(claims, api)
	claims["scope"] = "openid profile goaigua email"
	claims["user_name"] = "wipro.user1"
	
	logger.Info("msg", "successfully built access token claims", "total_claims", len(claims))
	return claims, nil
}

func setDefaultClaims(claims map[string]any, api orchestrator.Orchestrator) {
	// Set default scope if not present
	logger := api.Logger()
	if _, exists := claims["scope"]; !exists {
		claims["scope"] = "openid profile goaigua email"
		claims["azp"] = "go-aigua-portal"
		logger.Debug("msg", "set default scope")
	}

	// Set default email_verified if not present
	if _, exists := claims["email_verified"]; !exists {
		claims["email_verified"] = true
		logger.Debug("msg", "set default email_verified")
	}

	// Set default locale if not present
	if _, exists := claims["locale"]; !exists {
		claims["locale"] = "en"
		logger.Debug("msg", "set default locale")
	}

	// Set default ACR if not present
	if _, exists := claims["acr"]; !exists {
		claims["acr"] = "1"
		logger.Debug("msg", "set default acr")
	}

	// Set default AZP if not present
	if _, exists := claims["azp"]; !exists {
		claims["azp"] = "go-aigua-portal"
		logger.Debug("msg", "set default azp")
	}

	// Ensure user_name is set (fallback to email if needed)
	if _, exists := claims["user_name"]; !exists {
		if email, emailExists := claims["email"]; emailExists {
			claims["user_name"] = email
			logger.Debug("msg", "set user_name from email")
		}
	}

	// Ensure name is constructed if missing
	if _, exists := claims["name"]; !exists {
		if givenName, hasGiven := claims["given_name"]; hasGiven {
			if familyName, hasFamily := claims["family_name"]; hasFamily {
				claims["name"] = fmt.Sprintf("%v %v", givenName, familyName)
				logger.Debug("msg", "constructed name from given_name and family_name")
			}
		}
	}

	// Ensure preferred_username fallback
	if _, exists := claims["preferred_username"]; !exists {
		if email, emailExists := claims["email"]; emailExists {
			claims["preferred_username"] = email
			logger.Debug("msg", "set preferred_username from email")
		}
	}
}