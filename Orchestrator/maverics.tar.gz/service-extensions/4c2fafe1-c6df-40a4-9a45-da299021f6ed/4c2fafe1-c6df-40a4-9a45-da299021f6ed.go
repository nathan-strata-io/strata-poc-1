package main
import (
    "fmt"
	"net/http"
	"strings"
	"encoding/json"
	"time"
	"github.com/strata-io/service-extension/orchestrator"
)


func BuildAccessTokenClaims(api orchestrator.Orchestrator, req *http.Request) (map[string]any, error) {
	logger := api.Logger()
	logger.Debug("msg", "building Xylem Vue compatible access token claims")

	session, err := api.Session()
	if err != nil {
		logger.Error("msg", "unable to retrieve session", "error", err.Error())
		return nil, err
	}

	claims := make(map[string]any)
	
	// Define all possible session keys to check automatically
	possibleKeys := []string{
		// Standard JWT claims
		"sub", "email", "given_name", "family_name", "name", "preferred_username",
		"email_verified", "locale", "user_name", "scope", "acr", "azp", "nonce",
		"session_state", "jti", "auth_time",
		
		// Authorization specific claims
		"groups", "roles", "realm_access", "resource_access", "allowed-origins",
		
		// Generic prefixed claims
		"generic.sub", "generic.email", "generic.given_name", "generic.family_name",
		"generic.user_name", "generic.groups", "generic.roles", "generic.scope",
	}
	
	// IDP-specific claims
	idpPrefixes := []string{"Keycloak-1-XIAM", "Keycloak-2-Xylem-Vue", "Keycloak-3-XCloud"}
	idpClaimSuffixes := []string{
		"sub", "email", "given_name", "family_name", "name", "preferred_username",
		"email_verified", "groups", "roles", "realm_access", "resource_access",
		"scope", "acr", "azp", "nonce", "session_state", "jti", "auth_time",
		"user_name", "locale", "allowed-origins",
	}
	
	// Add IDP-specific keys to check
	for _, prefix := range idpPrefixes {
		for _, suffix := range idpClaimSuffixes {
			possibleKeys = append(possibleKeys, fmt.Sprintf("%s.%s", prefix, suffix))
		}
	}
	
	// Process all possible keys
	for _, key := range possibleKeys {
		value, err := session.GetString(key)
		if err != nil || value == "" {
			continue
		}
		
		logger.Debug("msg", "found session key for access token", "key", key, "value_length", len(value))
		
		// Skip internal/system keys
		if strings.HasPrefix(key, "pending.") || 
		   strings.HasPrefix(key, "universal.") ||
		   strings.Contains(key, ".authenticated") {
			continue
		}
		
		// Handle IDP-prefixed claims
		var claimName string
		var isIdpClaim bool
		
		for _, prefix := range idpPrefixes {
			if strings.HasPrefix(key, prefix+".") {
				claimName = strings.TrimPrefix(key, prefix+".")
				isIdpClaim = true
				break
			}
		}
		
		if isIdpClaim {
			claims[claimName] = parseAccessTokenClaimValue(value, api)
			logger.Debug("msg", "mapped IDP claim for access token", "original_key", key, "claim_name", claimName)
		} else {
			// Clean up generic prefixes
			cleanKey := key
			if strings.HasPrefix(key, "generic.") {
				cleanKey = strings.TrimPrefix(key, "generic.")
			}
			
			claims[cleanKey] = parseAccessTokenClaimValue(value, api)
			logger.Debug("msg", "mapped direct claim for access token", "original_key", key, "claim_name", cleanKey)
		}
	}
	
	// Add standard JWT claims for access tokens
	now := time.Now()
	
	// Set iat (issued at) if not present
	if _, exists := claims["iat"]; !exists {
		claims["iat"] = now.Unix()
	}
	
	// Set exp (expires) if not present (1 hour from now)
	if _, exists := claims["exp"]; !exists {
		claims["exp"] = now.Add(time.Hour).Unix()
	}
	
	// Set auth_time if not present
	if _, exists := claims["auth_time"]; !exists {
		claims["auth_time"] = now.Unix() - 60 // 1 minute ago as fallback
	}
	
	// Set issuer
	if _, exists := claims["iss"]; !exists {
		claims["iss"] = "https://maverics13.stratademo.io/realms/xylem"
	}
	
	// Set token type to Bearer for access tokens
	if _, exists := claims["typ"]; !exists {
		claims["typ"] = "Bearer"
	}
	
	// Ensure standard access token claims
	ensureAccessTokenClaims(claims, api)
	
	// Ensure Keycloak-style structure
	ensureAccessTokenKeycloakStructure(claims, api)
	
	logger.Info("msg", "returning Xylem Vue compatible access token claims", "total_claims", len(claims))
	for key, value := range claims {
		logger.Debug("msg", "access token claim", "key", key, "type", fmt.Sprintf("%T", value))
	}
	
	return claims, nil
}

// Helper function to parse access token claim values
func parseAccessTokenClaimValue(value string, api orchestrator.Orchestrator) interface{} {
	logger := api.Logger()
	
	// Try to parse as JSON array first
	if strings.HasPrefix(value, "[") && strings.HasSuffix(value, "]") {
		var array []string
		if err := json.Unmarshal([]byte(value), &array); err == nil {
			logger.Debug("msg", "parsed access token claim as JSON array", "length", len(array))
			return array
		}
		// Try as generic interface array for mixed types
		var genericArray []interface{}
		if err := json.Unmarshal([]byte(value), &genericArray); err == nil {
			logger.Debug("msg", "parsed access token claim as generic JSON array", "length", len(genericArray))
			return genericArray
		}
	}
	
	// Try to parse as JSON object
	if strings.HasPrefix(value, "{") && strings.HasSuffix(value, "}") {
		var obj map[string]interface{}
		if err := json.Unmarshal([]byte(value), &obj); err == nil {
			logger.Debug("msg", "parsed access token claim as JSON object", "keys", len(obj))
			return obj
		}
	}
	
	// Try to parse as boolean
	if value == "true" {
		return true
	}
	if value == "false" {
		return false
	}
	
	// Try to parse as number
	if num, err := json.Number(value).Int64(); err == nil {
		return num
	}
	if num, err := json.Number(value).Float64(); err == nil {
		return num
	}
	
	// Handle comma-separated values as arrays (common for scopes)
	if strings.Contains(value, ",") || strings.Contains(value, " ") {
		var parts []string
		if strings.Contains(value, ",") {
			parts = strings.Split(value, ",")
		} else {
			parts = strings.Split(value, " ")
		}
		
		if len(parts) > 1 {
			result := make([]string, 0, len(parts))
			for _, part := range parts {
				if trimmed := strings.TrimSpace(part); trimmed != "" {
					result = append(result, trimmed)
				}
			}
			if len(result) > 1 {
				logger.Debug("msg", "parsed access token claim as separated array", "length", len(result))
				return result
			}
		}
	}
	
	// Default to string
	return value
}

// Helper function to ensure standard access token claims
func ensureAccessTokenClaims(claims map[string]any, api orchestrator.Orchestrator) {
	logger := api.Logger()
	
	// Ensure sub exists
	if _, exists := claims["sub"]; !exists {
		if email, exists := claims["email"]; exists {
			claims["sub"] = email
			logger.Debug("msg", "fallback access token sub from email")
		}
	}
	
	// Ensure scope exists
	if _, exists := claims["scope"]; !exists {
		// Default scope for access tokens
		claims["scope"] = "openid profile email"
		logger.Debug("msg", "defaulted access token scope")
	}
	
	// Ensure email_verified if email exists
	if _, exists := claims["email"]; exists {
		if _, verified := claims["email_verified"]; !verified {
			claims["email_verified"] = true
			logger.Debug("msg", "defaulted access token email_verified to true")
		}
	}
	
	// Ensure user_name exists (Xylem Vue specific)
	if _, exists := claims["user_name"]; !exists {
		if email, exists := claims["email"]; exists {
			claims["user_name"] = email
			logger.Debug("msg", "fallback access token user_name from email")
		}
	}
	
	// Ensure name exists
	if _, exists := claims["name"]; !exists {
		if givenName, hasGiven := claims["given_name"]; hasGiven {
			if familyName, hasFamily := claims["family_name"]; hasFamily {
				claims["name"] = fmt.Sprintf("%v %v", givenName, familyName)
				logger.Debug("msg", "constructed access token name from given_name and family_name")
			}
		}
	}
	
	// Ensure preferred_username exists
	if _, exists := claims["preferred_username"]; !exists {
		if email, exists := claims["email"]; exists {
			claims["preferred_username"] = email
			logger.Debug("msg", "fallback access token preferred_username from email")
		}
	}
	
	// Set default locale
	if _, exists := claims["locale"]; !exists {
		claims["locale"] = "en"
		logger.Debug("msg", "defaulted access token locale to en")
	}
}

// Helper function to ensure Keycloak-style structure for access tokens
func ensureAccessTokenKeycloakStructure(claims map[string]any, api orchestrator.Orchestrator) {
	logger := api.Logger()
	
	// Set default audience (aud) - should include the client and relevant services
	if _, exists := claims["aud"]; !exists {
		claims["aud"] = []string{
			"realm-management",
			"go-aigua-water-twin", 
			"go-aigua-iot",
			"account",
			"go-aigua-dmd",
			"go-aigua-portal",
		}
		logger.Debug("msg", "defaulted access token audience")
	}
	
	// Handle realm_access structure
	if realmRoles, exists := claims["roles"]; exists {
		if _, realmAccessExists := claims["realm_access"]; !realmAccessExists {
			realmAccess := map[string]interface{}{
				"roles": realmRoles,
			}
			claims["realm_access"] = realmAccess
			logger.Debug("msg", "created access token realm_access structure from roles")
		}
	} else if _, realmAccessExists := claims["realm_access"]; !realmAccessExists {
		// Default realm roles if none exist
		realmAccess := map[string]interface{}{
			"roles": []string{
				"APP_DMD",
				"offline_access", 
				"uma_authorization",
			},
		}
		claims["realm_access"] = realmAccess
		logger.Debug("msg", "defaulted access token realm_access structure")
	}
	
	// Handle resource_access structure - create comprehensive structure
	if _, exists := claims["resource_access"]; !exists {
		resourceAccess := map[string]interface{}{
			"go-aigua-portal": map[string]interface{}{
				"roles": []string{
					"ADMIN_PORTAL_USERS",
					"PORTAL_APPS_ADMIN", 
					"ADMIN_PORTAL_GIS",
					"APP_PORTAL_ADMIN",
				},
			},
			"account": map[string]interface{}{
				"roles": []string{
					"manage-account",
					"manage-account-links",
					"view-profile",
				},
			},
		}
		claims["resource_access"] = resourceAccess
		logger.Debug("msg", "defaulted access token resource_access structure with portal and account roles")
	}
	
	// Handle allowed-origins
	if _, exists := claims["allowed-origins"]; !exists {
		claims["allowed-origins"] = []string{"*"}
		logger.Debug("msg", "defaulted access token allowed-origins")
	}
	
	// Generate session_state if not present
	if _, exists := claims["session_state"]; !exists {
		claims["session_state"] = fmt.Sprintf("session-%d", time.Now().Unix())
		logger.Debug("msg", "generated access token session_state")
	}
	
	// Set ACR (Authentication Context Class Reference)
	if _, exists := claims["acr"]; !exists {
		claims["acr"] = "1"
		logger.Debug("msg", "defaulted access token acr to 1")
	}
	
	// Set AZP (Authorized Party) - should be the client_id that requested the token
	if _, exists := claims["azp"]; !exists {
		claims["azp"] = "go-aigua-portal"
		logger.Debug("msg", "defaulted access token azp")
	}
}