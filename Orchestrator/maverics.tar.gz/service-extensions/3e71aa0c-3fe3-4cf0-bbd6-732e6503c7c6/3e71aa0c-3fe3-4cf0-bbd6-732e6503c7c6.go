package main

func BuildIDTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	logger := api.Logger()
	logger.Debug("msg", "building automated ID token claims from session")
	
	session, err := api.Session()
	if err != nil {
		logger.Error("msg", "unable to retrieve session", "error", err.Error())
		return nil, err
	}
	
	claims := make(map[string]any)
	
	// Get all session keys dynamically
	sessionKeys := session.Keys()
	
	logger.Debug("msg", "found session keys", "count", len(sessionKeys))
	
	// Define IDP prefixes to automatically discover
	idpPrefixes := []string{"Keycloak-1-XIAM", "Keycloak-2-Xylem-Vue", "Keycloak-3-XCloud"}
	
	// Process all session keys automatically
	for _, key := range sessionKeys {
		value, err := session.GetString(key)
		if err != nil || value == "" {
			continue
		}
		
		logger.Debug("msg", "processing session key", "key", key, "value_length", len(value))
		
		// Skip internal/system keys
		if strings.HasPrefix(key, "pending.") || 
		   strings.HasPrefix(key, "universal.") ||
		   strings.Contains(key, ".authenticated") {
			continue
		}
		
		// Handle IDP-prefixed claims - extract the actual claim name and map directly
		var claimName string
		var isIdpClaim bool
		
		for _, prefix := range idpPrefixes {
			if strings.HasPrefix(key, prefix+".") {
				// Extract claim name after the IDP prefix
				claimName = strings.TrimPrefix(key, prefix+".")
				isIdpClaim = true
				break
			}
		}
		
		// If it's an IDP claim, use the raw claim name (like Keycloak would)
		if isIdpClaim {
			claims[claimName] = parseClaimValue(value, logger)
			logger.Debug("msg", "mapped IDP claim", "original_key", key, "claim_name", claimName)
		} else {
			// For non-IDP claims, use the key as-is but clean up generic prefixes
			cleanKey := key
			if strings.HasPrefix(key, "generic.") {
				cleanKey = strings.TrimPrefix(key, "generic.")
			}
			
			claims[cleanKey] = parseClaimValue(value, logger)
			logger.Debug("msg", "mapped direct claim", "original_key", key, "claim_name", cleanKey)
		}
	}
	
	// Ensure standard OIDC claims are present with fallbacks
	ensureStandardClaims(claims, logger)
	
	// Log final claims
	logger.Info("msg", "returning automated ID token claims", "total_claims", len(claims))
	for key, value := range claims {
		logger.Debug("msg", "final claim", "key", key, "type", fmt.Sprintf("%T", value))
	}
	
	return claims, nil
}

// Helper function to parse claim values intelligently
func parseClaimValue(value string, logger orchestrator.Logger) interface{} {
	// Try to parse as JSON array first
	if strings.HasPrefix(value, "[") && strings.HasSuffix(value, "]") {
		var array []string
		if err := json.Unmarshal([]byte(value), &array); err == nil {
			logger.Debug("msg", "parsed as JSON array", "length", len(array))
			return array
		}
	}
	
	// Try to parse as JSON object
	if strings.HasPrefix(value, "{") && strings.HasSuffix(value, "}") {
		var obj map[string]interface{}
		if err := json.Unmarshal([]byte(value), &obj); err == nil {
			logger.Debug("msg", "parsed as JSON object", "keys", len(obj))
			return obj
		}
	}
	
	// Try to parse as boolean
	if value == "true" {
		return true
	}
	if value == "false" {
		return false
	}
	
	// Try to parse as number
	if num, err := json.Number(value).Int64(); err == nil {
		return num
	}
	if num, err := json.Number(value).Float64(); err == nil {
		return num
	}
	
	// Handle comma-separated values as arrays
	if strings.Contains(value, ",") && !strings.Contains(value, " ") {
		parts := strings.Split(value, ",")
		if len(parts) > 1 {
			result := make([]string, 0, len(parts))
			for _, part := range parts {
				if trimmed := strings.TrimSpace(part); trimmed != "" {
					result = append(result, trimmed)
				}
			}
			if len(result) > 1 {
				logger.Debug("msg", "parsed as comma-separated array", "length", len(result))
				return result
			}
		}
	}
	
	// Default to string
	return value
}

// Helper function to ensure standard OIDC claims are present
func ensureStandardClaims(claims map[string]any, logger orchestrator.Logger) {
	// Ensure sub exists
	if _, exists := claims["sub"]; !exists {
		if userID, exists := claims["SM_USER"]; exists {
			claims["sub"] = userID
			logger.Debug("msg", "fallback sub from SM_USER")
		} else if email, exists := claims["email"]; exists {
			claims["sub"] = email
			logger.Debug("msg", "fallback sub from email")
		}
	}
	
	// Ensure email_verified if email exists
	if _, exists := claims["email"]; exists {
		if _, verified := claims["email_verified"]; !verified {
			claims["email_verified"] = true
			logger.Debug("msg", "defaulted email_verified to true")
		}
	}
	
	// Ensure name exists if given_name and family_name exist
	if _, exists := claims["name"]; !exists {
		if givenName, hasGiven := claims["given_name"]; hasGiven {
			if familyName, hasFamily := claims["family_name"]; hasFamily {
				claims["name"] = fmt.Sprintf("%v %v", givenName, familyName)
				logger.Debug("msg", "constructed name from given_name and family_name")
			}
		}
	}
	
	// Map common variations
	if _, exists := claims["preferred_username"]; !exists {
		if email, exists := claims["email"]; exists {
			claims["preferred_username"] = email
			logger.Debug("msg", "fallback preferred_username from email")
		}
	}
}