package main

import (
	"fmt"
	"net/http"
	"strings"

	"github.com/strata-io/service-extension/orchestrator"
)

const (
	// IDP identifiers - All Keycloak IDPs
	xylem1ID = "Xylem1"
	xylem2ID = "Xylem2"
	xylem3ID = "Xylem3"

	// Domain constants
	xylemNorthAmericaDomain = "@xylem-na.com"
	xylemEuropeDomain       = "@xylem-eu.com"
	xylemAsiaPacificDomain  = "@xylem-apac.com"

	// Universal session key for cross-IDP authentication
	universalSessionKey = "maverics.unified.authenticated"
	universalUserKey    = "maverics.unified.user"
)

// extractDomain extracts the domain part from an email address
func extractDomain(email string) string {
	parts := strings.Split(email, "@")
	if len(parts) != 2 {
		return ""
	}
	return "@" + parts[1]
}

// IsAuthenticated determines if the user is authenticated from any IDP
func IsAuthenticated(
	api orchestrator.Orchestrator,
	_ http.ResponseWriter,
	_ *http.Request,
) bool {
	return checkIsAuthenticated(api)
}

func checkIsAuthenticated(api orchestrator.Orchestrator) bool {
	logger := api.Logger()
	sess, _ := api.Session()
	logger.Debug("msg", "determining if user is authenticated")

	// Check universal session first
	if isUniversallyAuthenticated(api) {
		logger.Debug("msg", "user is authenticated via universal session")
		return true
	}

	// Check Xylem1 Keycloak authentication
	xylem1Authenticated, _ := sess.GetString(fmt.Sprintf("%s.authenticated", xylem1ID))
	if xylem1Authenticated == "true" {
		logger.Debug("msg", "user is authenticated by Xylem1 Keycloak")
		mapClaim(api, xylem1ID+".sub", "generic.SM_USER")
		mapClaim(api, xylem1ID+".given_name", "generic.firstname")
		mapClaim(api, xylem1ID+".family_name", "generic.lastname")
		mapClaim(api, xylem1ID+".email", "generic.email")
		establishUniversalSession(api, xylem1ID)
		return true
	}

	// Check Xylem2 Keycloak authentication
	xylem2Authenticated, _ := sess.GetString(fmt.Sprintf("%s.authenticated", xylem2ID))
	if xylem2Authenticated == "true" {
		logger.Debug("msg", "user is authenticated by Xylem2 Keycloak")
		mapClaim(api, xylem2ID+".sub", "generic.SM_USER")
		mapClaim(api, xylem2ID+".given_name", "generic.firstname")
		mapClaim(api, xylem2ID+".family_name", "generic.lastname")
		mapClaim(api, xylem2ID+".email", "generic.email")
		establishUniversalSession(api, xylem2ID)
		return true
	}

	// Check Xylem3 Keycloak authentication
	xylem3Authenticated, _ := sess.GetString(fmt.Sprintf("%s.authenticated", xylem3ID))
	if xylem3Authenticated == "true" {
		logger.Debug("msg", "user is authenticated by Xylem3 Keycloak")
		mapClaim(api, xylem3ID+".sub", "generic.SM_USER")
		mapClaim(api, xylem3ID+".given_name", "generic.firstname")
		mapClaim(api, xylem3ID+".family_name", "generic.lastname")
		mapClaim(api, xylem3ID+".email", "generic.email")
		establishUniversalSession(api, xylem3ID)
		return true
	}

	return false
}

// isUniversallyAuthenticated checks if user has an active universal session
func isUniversallyAuthenticated(api orchestrator.Orchestrator) bool {
	sess, _ := api.Session()
	authenticated, _ := sess.GetString(universalSessionKey)
	return authenticated == "true"
}

// establishUniversalSession creates a universal session that works across all applications
func establishUniversalSession(api orchestrator.Orchestrator, sourceIDP string) {
	logger := api.Logger()
	sess, _ := api.Session()
	
	logger.Info("msg", "establishing universal session", "sourceIDP", sourceIDP)
	
	// Set universal authentication flag
	_ = sess.SetString(universalSessionKey, "true")
	_ = sess.SetString(universalUserKey, sourceIDP)
	
	// Copy user attributes to universal claims
	copyUserAttributes(api, sourceIDP)
	
	sess.Save()
	logger.Info("msg", "universal session established successfully")
}

// copyUserAttributes copies user attributes from source IDP to universal claims
func copyUserAttributes(api orchestrator.Orchestrator, sourceIDP string) {
	logger := api.Logger()
	sess, _ := api.Session()
	
	var sourceEmail, sourceFirstName, sourceLastName, sourceUser string
	
	switch sourceIDP {
	case xylem1ID:
		sourceEmail, _ = sess.GetString(xylem1ID + ".email")
		sourceFirstName, _ = sess.GetString(xylem1ID + ".given_name")
		sourceLastName, _ = sess.GetString(xylem1ID + ".family_name")
		sourceUser, _ = sess.GetString(xylem1ID + ".sub")
	case xylem2ID:
		sourceEmail, _ = sess.GetString(xylem2ID + ".email")
		sourceFirstName, _ = sess.GetString(xylem2ID + ".given_name")
		sourceLastName, _ = sess.GetString(xylem2ID + ".family_name")
		sourceUser, _ = sess.GetString(xylem2ID + ".sub")
	case xylem3ID:
		sourceEmail, _ = sess.GetString(xylem3ID + ".email")
		sourceFirstName, _ = sess.GetString(xylem3ID + ".given_name")
		sourceLastName, _ = sess.GetString(xylem3ID + ".family_name")
		sourceUser, _ = sess.GetString(xylem3ID + ".sub")
	}
	
	// Set universal attributes
	if sourceEmail != "" {
		_ = sess.SetString("universal.email", sourceEmail)
		logger.Debug("msg", "copied email to universal session", "email", sourceEmail)
	}
	if sourceFirstName != "" {
		_ = sess.SetString("universal.firstname", sourceFirstName)
		logger.Debug("msg", "copied firstname to universal session", "firstname", sourceFirstName)
	}
	if sourceLastName != "" {
		_ = sess.SetString("universal.lastname", sourceLastName)
		logger.Debug("msg", "copied lastname to universal session", "lastname", sourceLastName)
	}
	if sourceUser != "" {
		_ = sess.SetString("universal.user", sourceUser)
		logger.Debug("msg", "copied user to universal session", "user", sourceUser)
	}
}

// GetUniversalUserInfo retrieves user information from universal session
func GetUniversalUserInfo(api orchestrator.Orchestrator) (email, firstName, lastName, userID, sourceIDP string) {
	sess, _ := api.Session()
	
	email, _ = sess.GetString("universal.email")
	firstName, _ = sess.GetString("universal.firstname")
	lastName, _ = sess.GetString("universal.lastname")
	userID, _ = sess.GetString("universal.user")
	sourceIDP, _ = sess.GetString(universalUserKey)
	
	return
}

// CrossApplicationAuthentication validates if user can access any application
func CrossApplicationAuthentication(
	api orchestrator.Orchestrator,
	rw http.ResponseWriter,
	req *http.Request,
) bool {
	logger := api.Logger()
	
	// Check if user has universal session
	if isUniversallyAuthenticated(api) {
		email, firstName, lastName, userID, sourceIDP := GetUniversalUserInfo(api)
		
		logger.Info("msg", "user authenticated via universal session",
			"email", email,
			"firstName", firstName,
			"lastName", lastName,
			"userID", userID,
			"sourceIDP", sourceIDP,
		)
		
		// Ensure generic claims are set for application compatibility
		sess, _ := api.Session()
		_ = sess.SetString("generic.email", email)
		_ = sess.SetString("generic.firstname", firstName)
		_ = sess.SetString("generic.lastname", lastName)
		_ = sess.SetString("generic.SM_USER", userID)
		sess.Save()
		
		return true
	}
	
	// Fallback to individual IDP check
	return checkIsAuthenticated(api)
}

func mapClaim(api orchestrator.Orchestrator, oldClaim, newClaim string) {
	logger := api.Logger()
	sess, _ := api.Session()
	claimValue, _ := sess.GetString(oldClaim)
	if claimValue == "" {
		logger.Info(fmt.Sprintf("cannot map claim for %s", oldClaim))
		return
	}
	logger.Info(fmt.Sprintf("mapping new claim %s:%s", newClaim, claimValue))
	_ = sess.SetString(newClaim, claimValue)
	sess.Save()
}

// Authenticate authenticates the user against the appropriate IDP based on their email domain
func Authenticate(
	api orchestrator.Orchestrator,
	rw http.ResponseWriter,
	req *http.Request,
) {
	logger := api.Logger()
	logger.Info("msg", "authenticating user")

	hasIDPBeenPicked := req.FormValue("email")
	if !checkIsAuthenticated(api) && len(hasIDPBeenPicked) == 0 {
		logger.Debug("msg", "rendering idp picker")
		_, _ = rw.Write([]byte(fmt.Sprintf(idpForm, req.FormValue("SAMLRequest"))))
		return
	}

	if req.Method != http.MethodPost {
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		logger.Error(fmt.Sprintf(
			"received unexpected request type '%s', expected POST",
			req.Method,
		))
		return
	}

	logger.Info("msg", "parsing form from request")
	err := req.ParseForm()
	if err != nil {
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		logger.Error(fmt.Sprintf(
			"failed to parse form from request: %s",
			err,
		))
		return
	}

	email := req.Form.Get("email")
	domain := extractDomain(email)

	var idp string
	switch domain {
	case xylemNorthAmericaDomain:
		idp = xylem1ID
	case xylemEuropeDomain:
		idp = xylem2ID
	case xylemAsiaPacificDomain:
		idp = xylem3ID
	default:
		http.Error(
			rw,
			"Invalid email domain. Please use a valid Xylem domain.",
			http.StatusBadRequest,
		)
		logger.Error(fmt.Sprintf("invalid email domain: %s", domain))
		return
	}

	logger.Info(
		"msg", fmt.Sprintf("authenticating user with email '%s'", email),
		"domain", domain,
		"idp", idp,
	)

	provider, err := api.IdentityProvider(idp)
	if err != nil {
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		logger.Error(fmt.Sprintf("selected IDP '%s' was not found on AuthProvider", idp))
		return
	}

	logger.Info(fmt.Sprintf("Selected IDP '%s' was FOUND", idp))
	provider.Login(rw, req)
}

// LogoutFromAllSessions logs out user from universal session and all IDP sessions
func LogoutFromAllSessions(api orchestrator.Orchestrator) {
	logger := api.Logger()
	sess, _ := api.Session()
	
	logger.Info("msg", "logging out user from all sessions")
	
	// Clear universal session
	_ = sess.SetString(universalSessionKey, "false")
	_ = sess.SetString(universalUserKey, "")
	
	// Clear universal attributes
	_ = sess.SetString("universal.email", "")
	_ = sess.SetString("universal.firstname", "")
	_ = sess.SetString("universal.lastname", "")
	_ = sess.SetString("universal.user", "")
	
	// Clear generic claims
	_ = sess.SetString("generic.email", "")
	_ = sess.SetString("generic.firstname", "")
	_ = sess.SetString("generic.lastname", "")
	_ = sess.SetString("generic.SM_USER", "")
	
	// Clear IDP-specific sessions
	_ = sess.SetString(fmt.Sprintf("%s.authenticated", xylem1ID), "false")
	_ = sess.SetString(fmt.Sprintf("%s.authenticated", xylem2ID), "false")
	_ = sess.SetString(fmt.Sprintf("%s.authenticated", xylem3ID), "false")
	
	sess.Save()
	logger.Info("msg", "user logged out from all sessions")
}

// idpForm is the HTML form for email input with 3 Xylem Keycloak IDPs
const idpForm = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Xylem Identity Hub</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        :root {
            --xylem-blue: #0066CC;
            --xylem-dark-blue: #004C99;
            --xylem-light-gray: #F5F7FA;
            --xylem-green: #00A651;
        }
    </style>
</head>
<body class="bg-[#F5F7FA] min-h-screen flex flex-col gap-y-6 items-center justify-center">
    <div class="w-full max-w-md">
        <div class="text-center mb-8">
            <h1 class="text-3xl font-bold text-[#0066CC] mb-2">Xylem</h1>
            <p class="text-gray-600">Global Identity Hub</p>
        </div>
        
        <div class="bg-white rounded-xl shadow-lg p-8">
            <h2 class="text-2xl font-bold text-center mb-6 text-[#0066CC]">Welcome to Xylem Identity Hub</h2>
            <p class="text-gray-600 text-center mb-6">Please enter your Xylem email address to continue</p>
            
            <form method="POST" class="space-y-4">
                <input type="hidden" name="SAMLRequest" id="SAMLRequest" value="%s">
                
                <div class="space-y-2">
                    <label for="email" class="block text-sm font-medium text-gray-700">Email Address</label>
                    <input type="email" 
                           name="email" 
                           id="email" 
                           required 
                           placeholder="Enter your Xylem email address"
                           class="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#0066CC] focus:border-transparent">
                </div>
                
                <div class="bg-[#F5F7FA] p-4 rounded-md">
                    <h3 class="text-sm font-medium text-gray-700 mb-2">Supported Regions:</h3>
                    <ul class="text-xs text-gray-600 space-y-1">
                        <li>• <strong>North America:</strong> @xylem-na.com (Xylem1)</li>
                        <li>• <strong>Europe:</strong> @xylem-eu.com (Xylem2)</li>
                        <li>• <strong>Asia Pacific:</strong> @xylem-apac.com (Xylem3)</li>
                    </ul>
                </div>
                
                <button type="submit" 
                        class="w-full bg-[#0066CC] hover:bg-[#004C99] text-white font-semibold py-3 px-4 rounded-md transition-colors duration-200">
                    Continue to Xylem Authentication
                </button>
            </form>
            
            <div class="mt-6 text-center">
                <p class="text-xs text-gray-500">
                    Powered by Strata Identity Orchestrator
                </p>
            </div>
        </div>
    </div>
</body>
</html>
`