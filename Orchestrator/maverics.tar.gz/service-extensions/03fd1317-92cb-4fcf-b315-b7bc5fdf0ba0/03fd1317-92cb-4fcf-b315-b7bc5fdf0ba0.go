package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"time"

	"github.com/strata-io/service-extension/orchestrator"
)

// IdPConfig represents configuration for an Identity Provider
type IdPConfig struct {
	ID          string   `json:"id"`
	Name        string   `json:"name"`
	Domains     []string `json:"domains"`
	ClaimMaps   map[string]string `json:"claim_maps"`
	Priority    int      `json:"priority"`
}

// UniversalSession represents the universal session structure
type UniversalSession struct {
	UserID        string            `json:"user_id"`
	Email         string            `json:"email"`
	FirstName     string            `json:"first_name"`
	LastName      string            `json:"last_name"`
	DisplayName   string            `json:"display_name"`
	Groups        []string          `json:"groups"`
	Roles         []string          `json:"roles"`
	Department    string            `json:"department"`
	Organization  string            `json:"organization"`
	AuthenticatedIdPs []string      `json:"authenticated_idps"`
	SessionStart  time.Time         `json:"session_start"`
	LastActivity  time.Time         `json:"last_activity"`
	CustomClaims  map[string]string `json:"custom_claims"`
}

// Xylem IdP configurations matching your Strata setup
var defaultIdPConfigs = []IdPConfig{
	{
		ID:       "Keycloak-1-XIAM",
		Name:     "Xylem Identity Access Management",
		Domains:  []string{"@xylem-na.com", "@xylem1.com", "@na.xylem.com", "@wipro1.com"},
		Priority: 1,
		ClaimMaps: map[string]string{
			"sub":         "user_id",
			"given_name":  "first_name",
			"family_name": "last_name",
			"email":       "email",
			"name":        "display_name",
			"preferred_username": "username",
			"groups":      "groups",
			"department":  "department",
			"organization": "organization",
			"realm_access.roles": "roles",
		},
	},
	{
		ID:       "Keycloak-2-Xylem-Vue",
		Name:     "Xylem Vue Portal Identity",
		Domains:  []string{"@xylem-eu.com", "@xylem.com","@eu.xylem.com", "@europe.xylem.com", "@wipro.com"},
		Priority: 2,
		ClaimMaps: map[string]string{
			"sub":        "user_id",
			"email":      "email",
			"name":       "display_name",
			"given_name": "first_name",
			"family_name": "last_name",
			"preferred_username": "username",
			"groups":     "groups",
			"department": "department",
			"organization": "organization",
			"realm_access.roles": "roles",
		},
	},
	{
		ID:       "Keycloak-3-XCloud",
		Name:     "Xylem XCloud Identity",
		Domains:  []string{"@xylem-apac.com","@gmail.com", "@apac.xylem.com", "@asia.xylem.com"},
		Priority: 3,
		ClaimMaps: map[string]string{
			"sub":          "user_id",
			"given_name":   "first_name",
			"family_name":  "last_name",
			"email":        "email",
			"name":         "display_name",
			"preferred_username": "username",
			"groups":       "groups",
			"department":   "department",
			"organization": "organization",
			"realm_access.roles": "roles",
		},
	},
}

const (
	// Session keys
	universalSessionKey = "universal.session"
	sessionInitialized  = "universal.initialized"
	
	// Common claim prefixes
	genericPrefix = "generic."
)

// extractDomain extracts the domain part from an email address
func extractDomain(email string) string {
	parts := strings.Split(email, "@")
	if len(parts) != 2 {
		return ""
	}
	return "@" + parts[1]
}

// findIdPForDomain finds the appropriate IdP configuration for a given domain
func findIdPForDomain(domain string) *IdPConfig {
	for _, config := range defaultIdPConfigs {
		for _, configDomain := range config.Domains {
			if strings.EqualFold(domain, configDomain) {
				return &config
			}
		}
	}
	return nil
}

// IsAuthenticated determines if the user has a valid universal session
func IsAuthenticated(
	api orchestrator.Orchestrator,
	_ http.ResponseWriter,
	_ *http.Request,
) bool {
	return checkUniversalAuthentication(api)
}

func checkUniversalAuthentication(api orchestrator.Orchestrator) bool {
	logger := api.Logger()
	sess, _ := api.Session()
	
	logger.Debug("msg", "checking universal authentication status")
	
	// Check if universal session exists and is valid
	sessionData, err := sess.GetString(universalSessionKey)
	if err != nil || sessionData == "" {
		logger.Debug("msg", "no universal session found")
		return checkLegacyAuthentication(api)
	}
	
	var universalSession UniversalSession
	if err := json.Unmarshal([]byte(sessionData), &universalSession); err != nil {
		logger.Error("msg", "failed to parse universal session", "error", err)
		return checkLegacyAuthentication(api)
	}
	
	// Update last activity
	universalSession.LastActivity = time.Now()
	updatedSessionData, _ := json.Marshal(universalSession)
	_ = sess.SetString(universalSessionKey, string(updatedSessionData))
	sess.Save()
	
	// Set generic claims for backward compatibility
	setGenericClaims(api, &universalSession)
	
	logger.Debug("msg", "user authenticated via universal session", 
		"user_id", universalSession.UserID,
		"email", universalSession.Email)
	
	return true
}

func checkLegacyAuthentication(api orchestrator.Orchestrator) bool {
	logger := api.Logger()
	sess, _ := api.Session()
	
	logger.Debug("msg", "checking legacy authentication methods")
	
	// Check each configured IdP for existing authentication
	for _, config := range defaultIdPConfigs {
		authenticated, err := sess.GetString(fmt.Sprintf("%s.authenticated", config.ID))
		if err == nil && authenticated == "true" {
			logger.Debug("msg", "found legacy authentication", "idp", config.ID)
			
			// Migrate to universal session
			if migrateToUniversalSession(api, &config) {
				return true
			}
		}
	}
	
	return false
}

func migrateToUniversalSession(api orchestrator.Orchestrator, config *IdPConfig) bool {
	logger := api.Logger()
	sess, _ := api.Session()
	
	logger.Info("msg", "migrating legacy session to universal session", "idp", config.ID)
	
	universalSession := UniversalSession{
		AuthenticatedIdPs: []string{config.ID},
		SessionStart:      time.Now(),
		LastActivity:      time.Now(),
		CustomClaims:      make(map[string]string),
	}
	
	// Map claims from the legacy session
	for oldClaim, newField := range config.ClaimMaps {
		claimKey := fmt.Sprintf("%s.%s", config.ID, oldClaim)
		claimValue, err := sess.GetString(claimKey)
		if err != nil || claimValue == "" {
			continue
		}
		
		switch newField {
		case "user_id":
			universalSession.UserID = claimValue
		case "email":
			universalSession.Email = claimValue
		case "first_name":
			universalSession.FirstName = claimValue
		case "last_name":
			universalSession.LastName = claimValue
		case "display_name":
			universalSession.DisplayName = claimValue
		case "department":
			universalSession.Department = claimValue
		case "organization":
			universalSession.Organization = claimValue
		case "groups":
			// Handle groups (might be comma-separated or JSON array)
			if groups := parseGroups(claimValue); groups != nil {
				universalSession.Groups = groups
			}
		case "roles":
			// Handle roles (might be comma-separated or JSON array)
			if roles := parseGroups(claimValue); roles != nil {
				universalSession.Roles = roles
			}
		default:
			// Store as custom claim
			universalSession.CustomClaims[newField] = claimValue
		}
	}
	
	// Ensure we have essential fields
	if universalSession.UserID == "" {
		universalSession.UserID = universalSession.Email
	}
	if universalSession.DisplayName == "" {
		universalSession.DisplayName = fmt.Sprintf("%s %s", 
			universalSession.FirstName, universalSession.LastName)
	}
	
	// Store the universal session
	sessionData, err := json.Marshal(universalSession)
	if err != nil {
		logger.Error("msg", "failed to marshal universal session", "error", err)
		return false
	}
	
	_ = sess.SetString(universalSessionKey, string(sessionData))
	_ = sess.SetString(sessionInitialized, "true")
	sess.Save()
	
	// Set generic claims for immediate use
	setGenericClaims(api, &universalSession)
	
	logger.Info("msg", "successfully migrated to universal session", 
		"user_id", universalSession.UserID,
		"email", universalSession.Email)
	
	return true
}

func parseGroups(groupsStr string) []string {
	if groupsStr == "" {
		return nil
	}
	
	// Try to parse as JSON array first
	var groups []string
	if err := json.Unmarshal([]byte(groupsStr), &groups); err == nil {
		return groups
	}
	
	// Fall back to comma-separated values
	parts := strings.Split(groupsStr, ",")
	groups = make([]string, 0, len(parts))
	for _, part := range parts {
		if trimmed := strings.TrimSpace(part); trimmed != "" {
			groups = append(groups, trimmed)
		}
	}
	
	return groups
}

func setGenericClaims(api orchestrator.Orchestrator, session *UniversalSession) {
	sess, _ := api.Session()
	
	// Set standard generic claims
	_ = sess.SetString(genericPrefix+"SM_USER", session.UserID)
	_ = sess.SetString(genericPrefix+"email", session.Email)
	_ = sess.SetString(genericPrefix+"firstname", session.FirstName)
	_ = sess.SetString(genericPrefix+"lastname", session.LastName)
	_ = sess.SetString(genericPrefix+"displayname", session.DisplayName)
	_ = sess.SetString(genericPrefix+"department", session.Department)
	_ = sess.SetString(genericPrefix+"organization", session.Organization)
	
	// Set groups as JSON array
	if len(session.Groups) > 0 {
		groupsJson, _ := json.Marshal(session.Groups)
		_ = sess.SetString(genericPrefix+"groups", string(groupsJson))
	}
	
	// Set roles as JSON array
	if len(session.Roles) > 0 {
		rolesJson, _ := json.Marshal(session.Roles)
		_ = sess.SetString(genericPrefix+"roles", string(rolesJson))
	}
	
	// Set custom claims
	for key, value := range session.CustomClaims {
		_ = sess.SetString(genericPrefix+key, value)
	}
	
	sess.Save()
}

// Authenticate handles the authentication flow with intelligent IdP routing
func Authenticate(
	api orchestrator.Orchestrator,
	rw http.ResponseWriter,
	req *http.Request,
) {
	logger := api.Logger()
	logger.Info("msg", "starting universal authentication flow")
	
	// Check if already authenticated
	if checkUniversalAuthentication(api) {
		logger.Debug("msg", "user already authenticated")
		return
	}
	
	// Check if email has been provided
	email := req.FormValue("email")
	if email == "" && req.Method != http.MethodPost {
		logger.Debug("msg", "rendering email selection form")
		renderEmailForm(rw, req)
		return
	}
	
	if req.Method != http.MethodPost {
		http.Error(rw, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	
	// Parse form data
	if err := req.ParseForm(); err != nil {
		http.Error(rw, "Failed to parse form", http.StatusBadRequest)
		logger.Error("msg", "failed to parse form", "error", err)
		return
	}
	
	email = req.Form.Get("email")
	if email == "" {
		http.Error(rw, "Email is required", http.StatusBadRequest)
		return
	}
	
	// Extract domain and find appropriate IdP
	domain := extractDomain(email)
	idpConfig := findIdPForDomain(domain)
	
	if idpConfig == nil {
		http.Error(rw, "No identity provider configured for this email domain", 
			http.StatusBadRequest)
		logger.Error("msg", "no IdP found for domain", 
			"email", email, "domain", domain)
		return
	}
	
	logger.Info("msg", "routing to identity provider", 
		"email", email,
		"domain", domain,
		"idp", idpConfig.ID,
		"idp_name", idpConfig.Name)
	
	// Get the identity provider and initiate login
	provider, err := api.IdentityProvider(idpConfig.ID)
	if err != nil {
		http.Error(rw, "Identity provider not available", http.StatusInternalServerError)
		logger.Error("msg", "failed to get identity provider", 
			"idp", idpConfig.ID, "error", err)
		return
	}
	
	// Store the target IdP in session for post-auth processing
	sess, _ := api.Session()
	_ = sess.SetString("pending.idp", idpConfig.ID)
	_ = sess.SetString("pending.email", email)
	sess.Save()
	
	logger.Info("msg", "initiating login with identity provider", "idp", idpConfig.ID)
	provider.Login(rw, req)
}

// PostAuthenticate should be called after successful IdP authentication
// to establish the universal session
func PostAuthenticate(
	api orchestrator.Orchestrator,
	rw http.ResponseWriter,
	req *http.Request,
) {
	logger := api.Logger()
	sess, _ := api.Session()
	
	pendingIdP, err1 := sess.GetString("pending.idp")
	pendingEmail, err2 := sess.GetString("pending.email")
	
	if err1 != nil || pendingIdP == "" {
		logger.Error("msg", "no pending IdP found in session")
		http.Error(rw, "Authentication state error", http.StatusInternalServerError)
		return
	}
	
	logger.Info("msg", "processing post-authentication", 
		"idp", pendingIdP, "email", pendingEmail)
	
	// Find the IdP configuration
	var idpConfig *IdPConfig
	for _, config := range defaultIdPConfigs {
		if config.ID == pendingIdP {
			idpConfig = &config
			break
		}
	}
	
	if idpConfig == nil {
		logger.Error("msg", "IdP configuration not found", "idp", pendingIdP)
		http.Error(rw, "Configuration error", http.StatusInternalServerError)
		return
	}
	
	// Create universal session from the authenticated claims
	if createUniversalSession(api, idpConfig, pendingEmail) {
		// Clean up pending state
		_ = sess.SetString("pending.idp", "")
		_ = sess.SetString("pending.email", "")
		sess.Save()
		
		logger.Info("msg", "universal session established successfully")
	} else {
		logger.Error("msg", "failed to create universal session")
		http.Error(rw, "Session creation failed", http.StatusInternalServerError)
	}
}

func createUniversalSession(api orchestrator.Orchestrator, config *IdPConfig, email string) bool {
	logger := api.Logger()
	sess, _ := api.Session()
	
	// Check if the IdP authentication was successful
	authenticated, err := sess.GetString(fmt.Sprintf("%s.authenticated", config.ID))
	if err != nil || authenticated != "true" {
		logger.Error("msg", "IdP authentication not confirmed", "idp", config.ID)
		return false
	}
	
	return migrateToUniversalSession(api, config)
}

func renderEmailForm(rw http.ResponseWriter, req *http.Request) {
	samlRequest := req.FormValue("SAMLRequest")
	relayState := req.FormValue("RelayState")
	
	formHTML := fmt.Sprintf(emailRouterForm, samlRequest, relayState)
	rw.Header().Set("Content-Type", "text/html")
	_, _ = rw.Write([]byte(formHTML))
}

// LogoutFromAllSessions logs out user from universal session and all IDP sessions
func LogoutFromAllSessions(api orchestrator.Orchestrator) {
	logger := api.Logger()
	sess, _ := api.Session()
	
	logger.Info("msg", "logging out user from all sessions")
	
	// Clear universal session
	_ = sess.SetString(universalSessionKey, "")
	_ = sess.SetString(sessionInitialized, "false")
	
	// Clear generic claims
	_ = sess.SetString(genericPrefix+"email", "")
	_ = sess.SetString(genericPrefix+"firstname", "")
	_ = sess.SetString(genericPrefix+"lastname", "")
	_ = sess.SetString(genericPrefix+"SM_USER", "")
	_ = sess.SetString(genericPrefix+"displayname", "")
	_ = sess.SetString(genericPrefix+"department", "")
	_ = sess.SetString(genericPrefix+"organization", "")
	_ = sess.SetString(genericPrefix+"groups", "")
	_ = sess.SetString(genericPrefix+"roles", "")
	
	// Clear IDP-specific sessions
	for _, config := range defaultIdPConfigs {
		_ = sess.SetString(fmt.Sprintf("%s.authenticated", config.ID), "false")
	}
	
	sess.Save()
	logger.Info("msg", "user logged out from all sessions")
}

// Enhanced HTML form with Xylem branding and domain detection
const emailRouterForm = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Xylem Identity Hub - Universal Access</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        :root {
            --xylem-blue: #0066CC;
            --xylem-dark-blue: #004C99;
            --xylem-light-gray: #F5F7FA;
            --xylem-green: #00A651;
        }
        .domain-hint {
            font-size: 0.875rem;
            color: #6B7280;
            margin-top: 0.25rem;
        }
    </style>
</head>
<body class="bg-[#F5F7FA] min-h-screen flex flex-col gap-y-6 items-center justify-center">
    <div class="w-full max-w-md">
        <div class="text-center mb-8">
            <h1 class="text-3xl font-bold text-[#0066CC] mb-2">Xylem</h1>
            <p class="text-gray-600">Global Identity Hub</p>
        </div>
        
        <div class="bg-white rounded-xl shadow-lg p-8">
            <h2 class="text-2xl font-bold text-center mb-2 text-[#0066CC]">Universal Identity Access</h2>
            <p class="text-gray-600 text-center mb-6">Secure access to all Xylem applications worldwide</p>
            
            <form method="POST" class="space-y-4" id="authForm">
                <input type="hidden" name="SAMLRequest" value="%s">
                <input type="hidden" name="RelayState" value="%s">
                
                <div class="space-y-2">
                    <label for="email" class="block text-sm font-medium text-gray-700">Xylem Email Address</label>
                    <input type="email" 
                           name="email" 
                           id="email" 
                           required 
                           placeholder="Enter your Xylem email address"
                           class="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#0066CC] focus:border-transparent">
                    <div id="domainHint" class="domain-hint"></div>
                </div>
                
                <button type="submit" 
                        id="submitBtn"
                        class="w-full bg-[#0066CC] hover:bg-[#004C99] text-white font-semibold py-3 px-4 rounded-md transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed">
                    Continue to Xylem Authentication
                </button>
            </form>
            
            <div class="mt-6 bg-[#F5F7FA] p-4 rounded-md">
                <h3 class="text-sm font-medium text-gray-700 mb-2">Supported Xylem Regions:</h3>
                <div class="text-xs text-gray-600 space-y-1">
                    <p>• <strong>North America:</strong> @xylem-na.com, @xylem.com, @na.xylem.com</p>
                    <p>• <strong>Europe:</strong> @xylem-eu.com, @eu.xylem.com, @europe.xylem.com</p>
                    <p>• <strong>Asia Pacific:</strong> @xylem-apac.com, @apac.xylem.com, @asia.xylem.com</p>
                </div>
            </div>
            
            <div class="mt-6 text-center">
                <p class="text-xs text-gray-500">
                    Powered by Strata Identity Orchestrator
                </p>
            </div>
        </div>
    </div>

    <script>
        const emailInput = document.getElementById('email');
        const domainHint = document.getElementById('domainHint');
        const submitBtn = document.getElementById('submitBtn');
        
        const domainMappings = {
            '@xylem-na.com': 'Xylem Identity Access Management (North America)',
            '@xylem.com': 'Xylem Identity Access Management (North America)',
            '@na.xylem.com': 'Xylem Identity Access Management (North America)',
            '@wipro.com': 'Xylem Identity Access Management (North America)',
            '@xylem-eu.com': 'Xylem Vue Portal Identity (Europe)',
            '@eu.xylem.com': 'Xylem Vue Portal Identity (Europe)',
            '@europe.xylem.com': 'Xylem Vue Portal Identity (Europe)',
            '@xylem-apac.com': 'Xylem XCloud Identity (Asia Pacific)',
            '@apac.xylem.com': 'Xylem XCloud Identity (Asia Pacific)',
            '@asia.xylem.com': 'Xylem XCloud Identity (Asia Pacific)',
            '@gmail.com': 'Xylem XCloud IDentity gmail'
        };
        
        emailInput.addEventListener('input', function() {
            const email = this.value.toLowerCase();
            const domain = email.includes('@') ? '@' + email.split('@')[1] : '';
            
            if (domain && domainMappings[domain]) {
                domainHint.innerHTML = '✓ Will authenticate with: <strong>' + domainMappings[domain] + '</strong>';
                domainHint.style.color = '#059669';
                submitBtn.disabled = false;
            } else if (domain && email.includes('@')) {
                domainHint.innerHTML = '⚠ Domain not supported. Please use a valid Xylem domain.';
                domainHint.style.color = '#DC2626';
                submitBtn.disabled = true;
            } else {
                domainHint.innerHTML = '';
                submitBtn.disabled = false;
            }
        });
    </script>
</body>
</html>
`